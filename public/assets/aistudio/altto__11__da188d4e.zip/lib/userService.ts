// User Profile Service with reactive localStorage persistence
import { UserProfile } from '@/types';
export type { UserProfile };

const STORAGE_KEY = 'altto_user_profile';

export const AVATAR_PRESETS = [
  { id: 'gold', name: 'Luz Dourada', bg: 'bg-amber-100', text: 'text-amber-800', border: 'border-amber-300' },
  { id: 'cream', name: 'Creme Alvorada', bg: 'bg-stone-100', text: 'text-stone-800', border: 'border-stone-300' },
  { id: 'emerald', name: 'Oliveira Verde', bg: 'bg-emerald-100', text: 'text-emerald-800', border: 'border-emerald-300' },
  { id: 'sky', name: 'Céu Sagrado', bg: 'bg-sky-100', text: 'text-sky-800', border: 'border-sky-300' },
  { id: 'indigo', name: 'Noite de Vigília', bg: 'bg-indigo-100', text: 'text-indigo-800', border: 'border-indigo-300' },
];

export const DEFAULT_USER_PROFILE: UserProfile = {
  name: 'Anderson',
  email: 'anderson@email.com',
  avatarUrl: '',
  avatarPreset: 'gold',
  favoriteVerse: 'O Senhor é o meu pastor; nada me faltará. (Salmo 23:1)',
  bio: 'Buscando a Deus através da leitura diária da Palavra.',
  dailyGoalChapters: 3,
  streakDays: 1,
};

let cachedProfile: UserProfile = DEFAULT_USER_PROFILE;
let cachedRawString: string | null = null;
let isCacheLoaded = false;

export function getUserProfile(): UserProfile {
  if (typeof window === 'undefined') {
    return DEFAULT_USER_PROFILE;
  }
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!isCacheLoaded || saved !== cachedRawString) {
      cachedRawString = saved;
      isCacheLoaded = true;
      if (saved) {
        const parsed = JSON.parse(saved);
        cachedProfile = {
          name: parsed.name || 'Anderson',
          email: parsed.email || 'anderson@email.com',
          avatarUrl: parsed.avatarUrl || '',
          avatarPreset: parsed.avatarPreset || 'gold',
          favoriteVerse: parsed.favoriteVerse || 'O Senhor é o meu pastor; nada me faltará. (Salmo 23:1)',
          bio: parsed.bio || 'Buscando a Deus através da leitura diária da Palavra.',
          dailyGoalChapters: parsed.dailyGoalChapters || 3,
          streakDays: parsed.streakDays || 1,
          updatedAt: parsed.updatedAt,
        };
      } else {
        cachedProfile = DEFAULT_USER_PROFILE;
      }
    }
    return cachedProfile;
  } catch (err) {
    console.warn('Erro ao carregar perfil do usuário:', err);
    return cachedProfile || DEFAULT_USER_PROFILE;
  }
}

export function saveUserProfile(data: Partial<UserProfile>): UserProfile {
  const current = getUserProfile();
  const updated: UserProfile = {
    ...current,
    ...data,
    name: (data.name !== undefined ? data.name.trim() : current.name) || 'Anderson',
    updatedAt: new Date().toISOString(),
  };
  cachedProfile = updated;
  if (typeof window !== 'undefined') {
    try {
      const raw = JSON.stringify(updated);
      cachedRawString = raw;
      isCacheLoaded = true;
      localStorage.setItem(STORAGE_KEY, raw);
      window.dispatchEvent(new Event('altto_profile_updated'));
      
      // Async persist in indexedDB for extra durability
      import('@/lib/indexedDB').then(({ dbPut }) => {
        dbPut('user_profile', { ...updated, id: 'current_user' } as any).catch(() => {});
      }).catch(() => {});
    } catch (err) {
      console.error('Erro ao salvar perfil no localStorage:', err);
    }
  }
  return updated;
}

export function subscribeUserProfile(callback: () => void): () => void {
  if (typeof window === 'undefined') return () => {};
  const handleUpdate = () => {
    isCacheLoaded = false;
    callback();
  };
  window.addEventListener('altto_profile_updated', handleUpdate);
  window.addEventListener('storage', handleUpdate);
  return () => {
    window.removeEventListener('altto_profile_updated', handleUpdate);
    window.removeEventListener('storage', handleUpdate);
  };
}

import { useState, useEffect } from 'react';

export function useUserProfile(): UserProfile {
  const [profile, setProfile] = useState<UserProfile>(getUserProfile);

  useEffect(() => {
    const handleUpdate = () => {
      setProfile(getUserProfile());
    };
    window.addEventListener('altto_profile_updated', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener('altto_profile_updated', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, []);

  return profile;
}

export function processAvatarImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file || !file.type.startsWith('image/')) {
      reject(new Error('O arquivo selecionado não é uma imagem válida.'));
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const TARGET_SIZE = 256;
        canvas.width = TARGET_SIZE;
        canvas.height = TARGET_SIZE;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }

        // Center square crop
        const minDim = Math.min(img.width, img.height);
        const sx = (img.width - minDim) / 2;
        const sy = (img.height - minDim) / 2;

        ctx.fillStyle = '#FAF9FD';
        ctx.fillRect(0, 0, TARGET_SIZE, TARGET_SIZE);
        ctx.drawImage(img, sx, sy, minDim, minDim, 0, 0, TARGET_SIZE, TARGET_SIZE);

        const compressedBase64 = canvas.toDataURL('image/jpeg', 0.88);
        canvas.width = 0;
        canvas.height = 0;
        resolve(compressedBase64);
      };
      img.onerror = () => reject(new Error('Erro ao processar imagem de foto.'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Erro ao ler arquivo da imagem selecionada.'));
    reader.readAsDataURL(file);
  });
}
