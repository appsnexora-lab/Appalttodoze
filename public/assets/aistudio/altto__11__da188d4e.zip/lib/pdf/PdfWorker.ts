/**
 * PdfWorker.ts
 * Manages the PDF.js library instance and sets up the Web Worker for background processing.
 */
import * as pdfjsLib from 'pdfjs-dist';

let isWorkerInitialized = false;

export function initPdfWorker(): typeof pdfjsLib {
  if (typeof window === 'undefined') {
    return pdfjsLib;
  }
  if (!isWorkerInitialized) {
    try {
      const version = pdfjsLib.version || '4.10.38';
      // Use unpkg / cdnjs worker matching the exact pdfjs-dist runtime version
      if (!pdfjsLib.GlobalWorkerOptions.workerSrc) {
        pdfjsLib.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${version}/build/pdf.worker.min.mjs`;
      }
      isWorkerInitialized = true;
    } catch (e) {
      console.warn('PDF Worker initialization notice:', e);
    }
  }
  return pdfjsLib;
}

export { pdfjsLib };
